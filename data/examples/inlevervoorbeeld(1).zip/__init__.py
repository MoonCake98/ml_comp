"""
TrashClassifier 👋
Awesome classifier die als demo moet dienen
"""

from .TrashClassifier import TrashClassifier

def model_factory():
    # deze functie geeft een classifier terug. Merk op dat je hier
    # dus allerlei initialisatie- of hyperparameters kunt meegeven
    # omdat je complete controle hebt over wat er hier gebeurt.
    # Het werkt, zolang de classifier maar een methde `predict` heeft.

    return TrashClassifier(true_or_false=True)